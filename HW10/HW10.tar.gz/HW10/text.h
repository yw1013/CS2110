
void drawChar4(int row, int col, char ch, u8 index);
void drawString4(int row, int col, char *str, u8 index);



extern const unsigned char fontdata_6x8[12288];

