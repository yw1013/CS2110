#define DIDDY_WIDTH 105
#define DIDDY_HEIGHT 150
const unsigned short diddy_data[15750];
